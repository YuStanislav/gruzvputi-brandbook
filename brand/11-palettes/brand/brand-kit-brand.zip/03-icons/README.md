# Иконки «Груз в пути»

Подготовлены отдельные светлая и темная версии. Светлая использует фон `#F4F7FC` и темно-синий знак, темная — фон `#071426` и голубой знак `#6BABFF`. Надпись исключена, чтобы сохранить узнаваемость на маленьком экране.

## Содержимое

| Папка | Назначение | Размеры |
| --- | --- | --- |
| `ios/{light,dark}/` | PNG-исходники iPhone/iPad | 1024, 180, 167, 152, 120 px |
| `android/{light,dark}/` | Legacy/магазин, раздельные adaptive SVG | 512, 192, 144, 96, 72, 48 px |
| `android/{light,dark}/res/` | Android resource tree: adaptive API 26+, themed API 33+, legacy | mdpi → xxxhdpi |
| `web/{light,dark}/` | PWA, Apple touch, favicon, manifest | 192/512, 180, 16/32/48 px |
| `source/` | Квадратные редактируемые SVG-мастера | 1024 × 1024 |

`icon-masks-preview.png` показывает примеры системного скругления iOS, круглой Android-маски и скругленной PWA-маски. Маски применены только в превью. Исходники остаются квадратными.

## iPhone и iPad

PNG непрозрачные, без встроенных скругленных углов. Apple сама применяет маску; квадратный мастер 1024 × 1024 нужен для подготовки иконки в Xcode/Asset Catalog или Icon Composer. Набор — растровые мастера и версии для веб-ярлыков; многослойный `.icon`-проект не включен. Для актуальных эффектов Liquid Glass используйте мастер как основу и соберите слои в целевом инструменте Apple. Доступные appearances и конкретная конфигурация определяются целевой версией приложения. [Apple App Icons](https://developer.apple.com/design/human-interface-guidelines/app-icons).

## Android

В adaptive-версии foreground прозрачен, background вынесен отдельно. Холст соответствует 108 × 108 dp, основная графика целиком помещена в центральную безопасную окружность диаметром 66 dp. Размеры PNG foreground: 108, 162, 216, 324, 432 px по плотностям. Это слои, а не финальный размер значка на экране. [Android Adaptive Icons](https://developer.android.com/develop/ui/compose/system/icon_design_adaptive).

Скопируйте **одну выбранную тему** из `android/light/res` или `android/dark/res` в модуль приложения. Имена ресурсов одинаковы: две темы нельзя без переименования объединять в одну папку `res`. В AndroidManifest укажите `android:icon="@mipmap/ic_launcher"`. API 26 использует foreground/background, API 33 дополнительно получает векторный monochrome-слой для системной окраски. SVG-мастера оставлены отдельно для дальнейшей редакции. Проект Android здесь не компилировался: это набор ресурсов для интеграции.

`legacy-512.png` — квадратный PNG-мастер для листинга/передачи, `res/mipmap-*` — legacy launcher fallback. Скругление и тени не встроены в файлы.

## PWA и favicon

В каждой теме есть независимый `site.webmanifest` с относительными ссылками на обычные и maskable иконки. Скопируйте папку темы вместе с manifest в публичный каталог сайта. Отредактируйте `start_url`, `scope`, `name` при необходимости. Подключать следует manifest только одной активной темы; переключение темы интерфейса само по себе не гарантирует замену уже установленного PWA-значка.

Maskable-файлы имеют полноценный непрозрачный фон; значимая графика помещена внутрь окружности радиусом 40% ширины. Обычные PWA-версии крупнее по композиции. [Рекомендации maskable, web.dev](https://web.dev/articles/maskable-icon).

Пример для файлов, размещенных в `/brand-icons/light/` и `/brand-icons/dark/`:

```html
<link rel="manifest" href="/brand-icons/light/site.webmanifest">
<link rel="icon" href="/brand-icons/light/favicon.svg"
      media="(prefers-color-scheme: light)">
<link rel="icon" href="/brand-icons/dark/favicon.svg"
      media="(prefers-color-scheme: dark)">
<link rel="alternate icon" href="/brand-icons/light/favicon.ico">
<link rel="apple-touch-icon" href="/brand-icons/light/apple-touch-icon.png">
```

ICO содержит PNG-кадры 16, 32 и 48 px. Favicon дополнительно упрощен: исключены штрихи скорости и мелкое внутреннее ухо. На сайте с ручным переключателем темы обновляйте favicon в коде; media-атрибут следует настройке операционной системы.

## Проверка и пересборка

`../tools/build-logos.cjs` пересоздает весь набор через sharp. `validation.json` фиксирует проверку итоговых пикселей: непрозрачность и размеры iOS PNG, отсутствие живого текста в SVG, безопасные окружности Android и PWA. Просмотрите результат на реальном устройстве после подключения к приложению.

Технические требования сверены с официальными источниками **16 октября 2026**. Файлы подготовлены как набор для внедрения; они не устанавливают приложение и не создают публикацию в магазине.
